package ar.org.centro8.curso.java.entities;

import ar.org.centro8.curso.java.enums.EstadoCivil;

public class Detalles {
    private int id;
    private int id_factura;
    private int id_articulo;
    private int cantidad;
    private Double precio_unitario;
    
    
  
}

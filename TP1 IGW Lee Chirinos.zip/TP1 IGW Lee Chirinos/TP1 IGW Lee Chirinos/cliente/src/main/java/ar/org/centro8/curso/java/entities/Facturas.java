package ar.org.centro8.curso.java.entities;

import java.util.Date;

import ar.org.centro8.curso.java.enums.FormaDePago;

public class Facturas {
    private int id;
    private String letra;
    private int numero;
    private Date fecha;
    private Double monto;
    private FormaDePago forma_de_pago;
    private int id_cliente;

    public Facturas() {
    }
      
   
}

package ar.org.centro8.curso.java.enums;

public enum FormaDePago {
    EFECTIVO,
    TARJETA,
    DEBITO,
    CHEQUE
}
